#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <SDL.h>
#include <SDL_image.h>
#include "include/sokoban_io.h"
#include "include/sokoban_logic.h"
#include "include/sokoban_map.h"
enum {
    escape_button = 27,     //Az escape billentyu karakterkodja SDL-ben
};

/**
 * A surfaces struct elemei mind SDL_surface tipusuak.
 * Ebbe a strukturaba kell betölteni az összes a program altal hasznalt kepeket.
 * Ezek a kepek a palyakkat felepito elemek, a menu
 * es a palya elvegzese utan megjeleno uzenetek.
 */
typedef struct surfaces_struct {
    /** Celon levo doboz SDL felulete */
    SDL_Surface *box_des_surface;
    /** Padlon levo doboz SDL felulete */
    SDL_Surface *box_floor_surface;
    /** Karakter SDL felulete */
    SDL_Surface *character_surface;
    /** Cel SDL felulete */
    SDL_Surface *destination_surface;
    /** Padlo SDL felulete */
    SDL_Surface *floor_surface;
    /** Palyan kivuli resz SDL felulete */
    SDL_Surface *outside_surface;
    /** Fal SDL felulete */
    SDL_Surface *wall_surface;
    /** A menu SDL felulete */
    SDL_Surface *menu_surface;
    /** Palya vegzese utan megjeleno SDL felulet */
    SDL_Surface *level_completed_surface;
    /** Palya vegzese utan megjeleno SDL felulete,
     * ha a jatekos rekordot dontott
     */
    SDL_Surface *new_record_surface;

} surfaces_struct;


/**
 * A screen felulet globalis, mivel minden grafikus fugvenynek
 * erre kell betölteni az altala megjelenitendo feluleteket.
 */
SDL_Surface *screen;


/**
 * A get_surface fuggveny betölt egy,
 * a bemeneten megnevezett kepet a programba.
 * a betöltött kepet a kimeneten adja at SDL_Surface-re
 * mutato pointerkkent.
 */
SDL_Surface *get_surface(char *filename) {
    SDL_Surface *surface;
    surface = IMG_Load(filename);
    if(!surface) {
        printf("Nem sikerult megnyitni a kepet\n");
        exit(3);
    }
    return surface;
}

/**
 * A get_surfaces fuggveny minden kepet betölt amire a programnak
 * szuksege van a futashoz.
 * Ehez a get_surface fuggvenyt hasznalja mellyet minden kepre meghiv.
 * A betöltött kepeket egy surfaces_struct-ba tölti melynek memoriat foglal
 * es erre mutato pointerrel adja at a betöltött kepekket.
 */
surfaces_struct *get_surfaces(void) {
    surfaces_struct *surfaces = (surfaces_struct*)malloc(sizeof(surfaces_struct));
    surfaces->box_floor_surface = get_surface("box_floor.png");
    surfaces->box_des_surface = get_surface("box_des.png");
    surfaces->character_surface = get_surface("character.png");
    surfaces->destination_surface = get_surface("destination.png");
    surfaces->floor_surface = get_surface("floor.png");
    surfaces->outside_surface = get_surface("outside.png");
    surfaces->wall_surface = get_surface("wall.png");
    surfaces->menu_surface = get_surface("menu.png");
    surfaces->level_completed_surface = get_surface("level_completed.png");
    surfaces->new_record_surface = get_surface("new_record.png");
    return surfaces;
}

/**
 * A free_surfaces fuggveny felszabaditja a lefoglalt SDL feluleteket,
 * es az öket tartalmazo strukturat.
 * Ehez bemeneten varja a surfaces_struct strukkturara mutato pointert.
 */
void free_surfaces(surfaces_struct *surfaces) {
    SDL_FreeSurface(surfaces->box_floor_surface);
    SDL_FreeSurface(surfaces->box_des_surface);
    SDL_FreeSurface(surfaces->character_surface);
    SDL_FreeSurface(surfaces->destination_surface);
    SDL_FreeSurface(surfaces->floor_surface);
    SDL_FreeSurface(surfaces->outside_surface);
    SDL_FreeSurface(surfaces->wall_surface);
    SDL_FreeSurface(surfaces->menu_surface);
    SDL_FreeSurface(surfaces->level_completed_surface);
    SDL_FreeSurface(surfaces->new_record_surface);
    SDL_FreeSurface(screen);
    free(surfaces);
}


/**
 * A print_tile fuggveny egy darab palyaelem kirajzolasat vegzi.
 * Bemeneten varja a palyaelem SDL_Surface feluletet, es bal felso sarkanak
 * x, y koordinatajat.
 */
void print_tile(SDL_Surface *source, int x, int y) {
    SDL_Rect dest = {x * 50, y * 50, 0, 0};
    SDL_BlitSurface(source, NULL, screen, &dest);
}


/**
 * A print_map fuggveny bemeneten kapja a palya jelenlegi allapotat,
 * egy map_struct strukturara mutato pionterrel.
 * És az SDL feluleteket, egy surfaces_sructra mutato pointerrel
 * mellyek felhasznalasaval kirajzolja a kepernyore a palya jelenlegi allasat.
 */
void print_map(map_struct *map, surfaces_struct *surfaces) {
    int x, y;
    for(x = 0; x < map->height; x++) {
        for(y = 0; y < map->length; y++) {
            switch(map->tile[x][y]) {
            case wall        :
                print_tile(surfaces->wall_surface, y, x);
                break;
            case floor       :
                print_tile(surfaces->floor_surface, y, x);
                break;
            case character   :
                print_tile(surfaces->character_surface, y, x);
                break;
            case box_floor   :
                print_tile(surfaces->box_floor_surface, y, x);
                break;
            case outside     :
                print_tile(surfaces->outside_surface, y, x);
                break;
            case destination :
                print_tile(surfaces->destination_surface, y, x);
                break;
            case box_des     :
                print_tile(surfaces->box_des_surface, y, x);
                break;
            case char_des    :
                print_tile(surfaces->character_surface, y, x);
                break;
            }
        }
    }
    SDL_Flip(screen);
}


/**
 * Az open_map fuggveny bemeneten megkapja a megnyitando palya szamat,
 * es az surfaces_structra mutato pointert.
 * A fuggveny beolvassa textfile-bol a palyat, egy map_struct
 * strukturaba tölti, es kirajzolja a kepernyore.
 * Kimeneten visszaadja a palyat leiro map_struct strukturat.
 */
map_struct * open_map(int map_number, surfaces_struct *surfaces) {
    map_struct *map = choose_map(map_number);
    screen = SDL_SetVideoMode(map->length * 50, map->height * 50, 0, SDL_ANYFORMAT);
    print_map(map, surfaces);
    return map;
}


/**
 * A button pressed fuggveny feladata a menuben törteno
 * eger kattintasok helyet figyelni, es ha az egy palyat
 * jelzo dobozon törtent annak a palyanak a szamat visszaadni a kimeneten.
 * Ehez a bemeneten az eger kattintas x, es y koordinatajat varja.
 */
int button_pressed(int mouse_x, int mouse_y) {
    if(mouse_y > 200 && mouse_y < 250 && mouse_x < 600) {
        if(mouse_x%100 > 50) {
            mouse_x = mouse_x - 50;
        }
        return mouse_x /100;
    }
    return -1;
}


int main(int argc, char *argv[]) {
    char player_name[8];
    scanf("%s", player_name);

    SDL_Event event;
    SDL_Init(SDL_INIT_VIDEO);
    SDL_WM_SetCaption("Sokoban","Sokoban");
    screen = SDL_SetVideoMode(642, 400, 0, SDL_ANYFORMAT);
    if(!screen) {
        exit(3);
    }

    surfaces_struct *surfaces = get_surfaces();
    SDL_BlitSurface(surfaces->menu_surface, NULL, screen, NULL);
    SDL_Flip(screen);
    bool quit = false;
    bool return_menu = false;
    int map_number;
    int command;

    while(!quit) {
        SDL_WaitEvent(&event);
        switch(event.type) {
        case SDL_QUIT :
            quit = true;
            break;
        case SDL_MOUSEBUTTONDOWN :
            if (event.button.button == SDL_BUTTON_LEFT) {
                map_number = button_pressed(event.button.x, event.button.y);
                if(map_number > 0) {
                    map_struct *map = open_map(map_number, surfaces);
                    while(!quit && !return_menu && map->box_count != map->in_des) {
                        SDL_WaitEvent(&event);
                        switch(event.type) {
                        case SDL_QUIT :
                            quit = true;
                            break;
                        case SDL_KEYDOWN :
                            command = event.key.keysym.sym;
                            switch(command) {
                            case escape_button :
                                return_menu = true;
                                break;
                            case 'R':
                            case 'r':
                                free_map(map);
                                map = open_map(map_number, surfaces);
                                break;
                            default :
                                step(map, command);
                                print_map(map, surfaces);
                            }
                        }
                    }
                    if(map->box_count == map->in_des) {
                        bool new_record = record(map_number, player_name, map->steps);
                        screen = SDL_SetVideoMode(640, 400, 0, SDL_ANYFORMAT);
                        if(new_record) {
                            SDL_BlitSurface(surfaces->new_record_surface, NULL, screen, NULL);
                        }
                        else {
                            SDL_BlitSurface(surfaces->level_completed_surface, NULL, screen, NULL);
                        }
                        SDL_Flip(screen);
                        new_record = false;
                        while(!return_menu) {
                            SDL_WaitEvent(&event);
                            if(event.type == SDL_KEYDOWN)
                                return_menu = true;
                        }
                    }
                }
                screen = SDL_SetVideoMode(640, 400, 0, SDL_ANYFORMAT);
                SDL_BlitSurface(surfaces->menu_surface, NULL, screen, NULL);
                SDL_Flip(screen);
                return_menu = false;
            }
        }
    }
    free_surfaces(surfaces);
    SDL_Quit();

    return 0;
}
