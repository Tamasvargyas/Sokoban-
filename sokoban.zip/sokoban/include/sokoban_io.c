#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "sokoban_map.h"
#include "sokoban_io.h"

/**
 * A scan_map fuggveny feladata a palya beolvasasa
 * a megadott text fajlbol. Ehez csupan a fajl nevere
 * van szuksege.
 * A fugveny visszateresi erteke, ha sikerult a beolvasas
 * egy map_structra mutato pointer melyben elerhetõ a palya szelessege,
 * magassaga es a palyaelemek, melyek matrixkent cimezhetõek.
 * Ha nem sikerult a beolvasas a visszateresi ertek egy NULL pointer.
 */
map_struct *scan_map(char *map_name) {
    FILE* map_file;
    map_file = fopen(map_name, "rt");

    /* ha nem sikerult a fajlt megnyitni a fuggveny
       NULL pointerrel ter vissza */
    if(map_file != NULL) {
        int heigth, length;
        int could_read = fscanf(map_file,"%dx%d\n", &heigth, &length);
        if(could_read == 0) {
            printf("Uncorrect map dimentions.");
            exit(2);
        }
        tile_type **tile;

        /* memoria foglalas a palyanak. Mivel matrixkent akarjuk
           cimezni ezert elõszor egy magassag meretû sort foglal le
           melyben pointerek mutatnak szelesseg meretû sorokra.*/
        int x;
        tile = (tile_type**) malloc(heigth * sizeof(tile_type*));
        for (x = 0; x < heigth; x++)
            tile[x] = (tile_type*) malloc(length * sizeof(tile_type));

        /* palya beolvasasa a text fajlbol, es betoltese a memoriaba */
        int y, char_x, char_y, box_count = 0, in_des_count = 0;
        for(x = 0; x < heigth; x++) {
            char temp;
            for(y = 0; y < length ; y++) {
                could_read = fscanf(map_file, "%c", &temp);
                if(could_read != 1) {
                    printf("Corrupted map file");
                    exit(2);
                }
                switch(temp) {
                case 'W' :
                    tile[x][y] = wall;
                    break;
                case 'F' :
                    tile[x][y] = floor;
                    break;
                case 'C' :
                    tile[x][y] = character;
                    char_x = x, char_y = y;
                    break;
                case 'B' :
                    tile[x][y] = box_floor;
                    box_count++;
                    break;
                case 'O' :
                    tile[x][y] = outside;
                    break;
                case 'D' :
                    tile[x][y] = destination;
                    break;
                case 'X' :
                    tile[x][y] = box_des;
                    box_count++;
                    in_des_count++;
                    break;
                default  :
                    return NULL;
                    break;
                }
            }
            fscanf(map_file, "\n"); /* A palyaleirasban a sorokat "Új sor" jel zarja,
                                       de ezeket a programba nem szabad beolvasni */
        }
        /* Palya struktúraba toltese es visszaadasa */
        map_struct *map = (map_struct*) malloc(sizeof(map_struct));

        map->height = heigth;       //Palya magassaga
        map->length = length;       //Palya szelessege
        map->char_x = char_x;       //Karakter x koordinataja
        map->char_y = char_y;       //Karakter y koordinataja
        map->box_count = box_count; //Dobozok szama
        map->in_des = in_des_count; //Celon levõ dobozok szama
        map->char_on_des = false;   //A karakter kezdetben sosem lehet celon
        map->steps = 0;             //A palya beolvasaskor 0-t leptunk
        map->tile = tile;           //A palyanak foglalt memoriara mutato pointer
        return map;
    }
    else {
        exit(1);

    }
    return NULL;

}


/**
 * A free_map fuggneny dolga, hogy felszabaditsa a scan_map-ban
 * foglalt memoriat. Ehhez a map_struct tipusu map-ra mutato pointert varja
 * bemeneten.
 */
void free_map(map_struct *map) {
    if(map == NULL)
        return;
    int x;
    for (x = 0; x < map->height; x++)
        free(map->tile[x]);             //Elõszor a palya sorait kell felszabaditani
    free(map->tile);                    //Majd az ezekre mutato pointereket
    free(map);                          //Vegul a palya adatait tartalmazo struktúra elemet
}


/**
 * A choose_map fuggveny feladata a megfelelõ fajlnev atadasa a
 * scan_map fugvenynek, a menuben adott palyaszam alapjan.
 */
map_struct *choose_map(int map_number) {
    switch(map_number) {
    case 1 :
        return scan_map("maps\\map1.txt");
        break;
    case 2 :
        return scan_map("maps\\map2.txt");
        break;
    case 3 :
        return scan_map("maps\\map3.txt");
        break;
    case 4 :
        return scan_map("maps\\map4.txt");
        break;
    case 5 :
        return scan_map("maps\\map5.txt");
        break;
    default :
        return NULL;
        break;
    }
}
/**
 * A record_struct a dicsoseglista fajlbol valo betolteset
 * majd fajlba valo kiirasat segiti.
 * Tarolja a palya szamat,
 * a rekord tarto jatekos nevet
 * es az altala megtett lepesekk szamat
 * amennyivel elvegezte a palyat.
 */
typedef struct record_struct {
    /** A palya szama */
    int map_number;
    /** A jatekos neve, max 8 karakter */
    char player_name[8];
    /** Az eddigi legkissebb lepesszam */
    int steps_taken;
} record_struct;

/**
 * a record fuggneny bemeneten egy palyaszamot, jatekosnevet,
 * es a megtett lepesek szamat varja.
 * Feladata beolvasni a dicsoseglistat tartalmazo textfilet
 * eldonteni, hogy az adott palyara új rekord szuletett-e,
 * es ha igen ezt beleirni a fajlba.
 * kimeneten visszaadja, hogy új rekord szuletett-e.
 */
bool record(int map_number, char *player_name, int steps_taken) {


    FILE *fr = fopen("maps\\step_records.txt","rt");
    int map_count;
    fscanf(fr, "%d\n", &map_count);
    record_struct *records = (record_struct*)malloc(sizeof(record_struct) * map_count);
    bool new_record;
    int i;
    for (i = 0; i < 5; i++) {
        fscanf(fr, "%d %d %s\n", &records[i].map_number, &records[i].steps_taken, records[i].player_name);
        if(records[i].map_number == map_number) {
            if(records[i].steps_taken < 0 || records[i].steps_taken > steps_taken) {
                records[i].steps_taken = steps_taken;
                strcpy(records[i].player_name, player_name);
                new_record = true;
            }
        }
    }
    fclose(fr);
    FILE *fw = fopen("maps\\step_records.txt","wt");
    fprintf(fw,"%d\n", map_count);
    for (i = 0; i < 5; i++) {
        fprintf(fw, "%d %d %s\n", records[i].map_number, records[i].steps_taken, records[i].player_name);
    }
    fclose(fw);
    free(records);
    return new_record;
}
