#ifndef SOKOBAN_IO_H_INCLUDED
#define SOKOBAN_IO_H_INCLUDED
#include "sokoban_map.h"

/**
 * A scan_map fuggveny feladata a palya beolvasasa
 * a megadott text fajlbol. Ehez csupan a fajl nevere
 * van szuksege.
 * A fugveny visszateresi erteke, ha sikerult a beolvasas
 * egy map_structra mutato pointer melyben elerhetõ a palya szelessege,
 * magassaga es a palyaelemek, melyek matrixkent cimezhetõek.
 * Ha nem sikerult a beolvasas a visszateresi ertek egy NULL pointer.
 */
map_struct *scan_map(char *map_name);

/**
 * A free_map fuggneny dolga, hogy felszabaditsa a scan_map-ban
 * foglalt memoriat. Ehhez a map_struct tipusu map-ra mutato pointert varja
 * bemeneten.
 */
void free_map(map_struct *map);


/**
 * A choose_map fuggveny feladata a megfelelõ fajlnev atadasa a
 * scan_map fugvenynek, a menuben adott palyaszam alapjan.
 */
map_struct *choose_map(int map_number);


/**
 * a record fuggneny bemeneten egy palyaszamot, jatekosnevet,
 * es a megtett lepesek szamat varja.
 * Feladata beolvasni a dicsoseglistat tartalmazo textfilet
 * eldonteni, hogy az adott palyara új rekord szuletett-e,
 * es ha igen ezt beleirni a fajlba.
 * kimeneten visszaadja, hogy új rekord szuletett-e.
 */
bool record(int map_number, char *player_name, int steps_taken);

#endif // SOKOBAN_IO_H_INCLUDED
