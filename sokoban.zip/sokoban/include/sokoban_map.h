#ifndef MAP_H_INCLUDED
#define MAP_H_INCLUDED

/**
 * A palyan fellelheto palyaelemek tipusai
 */
typedef enum tile_type {
    /** Fal */
    wall,
    /** padlo */
    floor,
    /** karakkter */
    character,
    /** padlon levo doboz */
    box_floor,
    /** palyan kivuli resz */
    outside,
    /** cel */
    destination,
    /** celon levo karakter */
    char_des,
    /** celon levo doboz */
    box_des
} tile_type;

/**
 * a map strukturaban a palyahoz tartozo
 * osszes fontos adat megtalalhato
 */
typedef struct map_struct {
    /** A palya magassaga */
    int height;
    /** A palya szelessege */
    int length;
    /** A Karakter x koordinataja */
    int char_x;
    /** A Karakter y koordinataja */
    int char_y;
    /** Dobozok szama a palyan */
    int box_count;
    /** celon levo dobozok szama */
    int in_des;
    /** Jelzi ha a karakter eppen destination, azaz 'cel' blokkon all */
    bool char_on_des;
    /** Lepesek szama; */
    int steps;
    /** A pallyanak dinamikusan foglalt memoriara mutato pointer */
    tile_type **tile;
} map_struct;


#endif // MAP_H_INCLUDED
