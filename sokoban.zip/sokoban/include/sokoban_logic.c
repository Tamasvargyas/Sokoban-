#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "sokoban_map.h"
#include "sokoban_logic.h"
enum {
    /** A fel nyil karakterkódja SDL-ben */
    up = 273,
    /** A le nyil karakterkódja SDL-ben */
    down = 274,
    /** A jobbra nyil karakterkódja SDL-ben */
    right = 275,
    /** A ballra nyil karakterkódja SDL-ben */
    left = 276,
};

/**
 * A step_tile_switch fuggveny felelõs lepesenkent atirni a valtozó teruletek tipusat.
 * ehez meg kell adnuk a palyara mutató map_struct tipusu map pointert, a lepes horizontalis
 * es vertikalis komponenset, es hogy mire valtoztassa a ketto terulet tipusat.
 */
void step_tile_switch(map_struct *map, int hor, int ver, tile_type tile1, tile_type tile2) {
    map->tile[map->char_x][map->char_y] = tile1;
    map->char_x = map->char_x + ver;
    map->char_y = map->char_y + hor;
    map->tile[map->char_x][map->char_y] = tile2;
}

/**
 * A step_execute fuggveny feladata, hogy a karakter celról lelepve
 * celt hagyjon maga utan, ne padlót.
 * Bemeneten varja a palyara mutato map_struct tipusu
 * map pointert,
 * a lepes horizontalis, es vertikalis komponenset
 * es a leptetett, elem tipusat.
 */

void step_execute(map_struct *map, int hor, int ver, tile_type tile) {
    if(!map->char_on_des)
        step_tile_switch(map, hor, ver, floor, tile);
    else
        step_tile_switch(map, hor, ver, destination, tile);
}


/**
 * Az offset_struct tarolja a lepteteseknel
 * a palyaelem indexek valtozasat
 */
typedef struct offset_stuct{
    /** Horizontalis komponens */
    int hor;
    /** Vertikalis komponens */
    int ver;
    /** Kell-e lepni a bemenet alapjan */
    bool do_step;
}offset_struct;

/**
 * A step_offset fuggveny szamolja ki egy adott lepesnek a horizontalis,
 * es vertikalis komponenseit amivel a palyaelem indexeit valtoztatni kell.
 * bemenete a map_struct tupusu map pointer, es egy lepesirany.
 * Kimeneten egy offset strukturaban adja meg a kiszamolt horizontalis,
 * es vertikalis komponenst, es, hogy kell-e egyanltalan lepni.
 */
offset_struct step_offset( map_struct *map, int step_dir) {
    offset_struct offset;
    switch(step_dir) {
    case up :
    case 'W' :
    case 'w' :
        offset.hor = 0;
        offset.ver = -1;
        map->steps++;
        break;
    case right :
    case 'D' :
    case 'd' :
        offset.hor = 1;
        offset.ver = 0;
        map->steps++;
        break;
    case down :
    case 'S' :
    case 's' :
        offset.hor = 0;
        offset.ver = 1;
        map->steps++;
        break;
    case left :
    case 'A' :
    case 'a' :
        offset.hor = -1;
        offset.ver = 0;
        map->steps++;
        break;
    default  :
        offset.hor = 0;
        offset.ver = 0;
        offset.do_step = false;
        break;
    }
    offset.do_step = true;
    return offset;
}


/**
 * A step fuggveny funkciója a palyan leptetni a karaktert, es altala
 * a dobozokat. Ehez a map_struct tipusu map pointerre van szuksege,
 * es egy iranyra, mellyet a W, A, S, D, avagy a nyilak adhatnak.
 * A fuggveny a palya leptetes utani allapotat adja vissza,
 * a map strukturara mutató pointerrel.
 */
map_struct *step(map_struct *map, int step_dir) {
    offset_struct offset = step_offset(map, step_dir);
    if(offset.do_step) {
        int pos_after_x = map->char_x + offset.ver * 2;
        int pos_after_y = map->char_y + offset.hor * 2;
        tile_type next_pos = map->tile[map->char_x + offset.ver][map->char_y + offset.hor];
        tile_type pos_after = map->tile[pos_after_x][pos_after_y];
        switch(next_pos) {

        case floor :
            step_execute(map, offset.hor, offset.ver, character);
            map->char_on_des = false;
            break;
        case box_floor :
            if(pos_after == floor) {
                map->tile[pos_after_x][pos_after_y] = box_floor;
                step_execute(map, offset.hor, offset.ver, character);
            }
            else if(pos_after == destination) {
                map->tile[pos_after_x][pos_after_y] = box_des;
                map->in_des++;
                step_execute(map, offset.hor, offset.ver, character);
            }
            map->char_on_des = false;
            break;
        case destination :
            step_execute(map, offset.hor, offset.ver, char_des);
            map->char_on_des = true;
            break;
        case box_des :
            if(pos_after == floor) {
                map->tile[pos_after_x][pos_after_y] = box_floor;
                map->in_des--;
                step_execute(map, offset.hor, offset.ver, char_des);
            }
            else if(pos_after == destination) {
                map->tile[pos_after_x][pos_after_y] = box_des;
                step_execute(map, offset.hor, offset.ver, char_des);
            }
            map->char_on_des = true;
            break;
        default :
            break;
        }
    }
    return map;
}
