#ifndef SOKOBAN_LOGIC_H_INCLUDED
#define SOKOBAN_LOGIC_H_INCLUDED
#include "sokoban_map.h"
map_struct *step(map_struct *map, int step_dir);


#endif // SOKOBAN_LOGIC_H_INCLUDED
