var searchData=
[
  ['outside',['outside',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557ac8da1cf898317d8ad0684c8e696e7e7f',1,'sokoban_map.h']]]
];
