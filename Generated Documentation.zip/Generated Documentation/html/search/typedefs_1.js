var searchData=
[
  ['offset_5fstruct',['offset_struct',['../sokoban__logic_8c.html#afa60ae58827677bbe7375d89183a6239',1,'sokoban_logic.c']]]
];
