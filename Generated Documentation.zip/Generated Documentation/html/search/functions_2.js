var searchData=
[
  ['free_5fmap',['free_map',['../sokoban__io_8c.html#afdfc830905135788f014a9dd2e068283',1,'free_map(map_struct *map):&#160;sokoban_io.c'],['../sokoban__io_8h.html#afdfc830905135788f014a9dd2e068283',1,'free_map(map_struct *map):&#160;sokoban_io.c']]],
  ['free_5fsurfaces',['free_surfaces',['../main_8c.html#a3bf575588a75b4679c49c7be38ca6fdc',1,'main.c']]]
];
