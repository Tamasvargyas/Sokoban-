var searchData=
[
  ['map_5fstruct',['map_struct',['../structmap__struct.html',1,'']]]
];
