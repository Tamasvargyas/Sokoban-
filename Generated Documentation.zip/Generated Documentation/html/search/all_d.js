var searchData=
[
  ['record',['record',['../sokoban__io_8c.html#ad4bff0a4e6278130f71b62593659fdeb',1,'record(int map_number, char *player_name, int steps_taken):&#160;sokoban_io.c'],['../sokoban__io_8h.html#ad4bff0a4e6278130f71b62593659fdeb',1,'record(int map_number, char *player_name, int steps_taken):&#160;sokoban_io.c']]],
  ['record_5fstruct',['record_struct',['../structrecord__struct.html',1,'record_struct'],['../sokoban__io_8c.html#a344248fef48d77b9c16efe8a51184111',1,'record_struct():&#160;sokoban_io.c']]],
  ['right',['right',['../sokoban__logic_8c.html#a06fc87d81c62e9abb8790b6e5713c55baf763d610923b0c4614e8ecd65212666a',1,'sokoban_logic.c']]]
];
