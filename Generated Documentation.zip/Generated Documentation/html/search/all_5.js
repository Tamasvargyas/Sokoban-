var searchData=
[
  ['get_5fsurface',['get_surface',['../main_8c.html#ae9a136fcbcdd1a298b713713151f88b4',1,'main.c']]],
  ['get_5fsurfaces',['get_surfaces',['../main_8c.html#a7bad3db91be0fc0e37d9d09a88ba5eba',1,'main.c']]]
];
