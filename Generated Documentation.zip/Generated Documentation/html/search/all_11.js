var searchData=
[
  ['ver',['ver',['../structoffset__stuct.html#a88ca8dd6d8b1535e6ba06c4d988c525b',1,'offset_stuct']]]
];
