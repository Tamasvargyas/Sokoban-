var searchData=
[
  ['scan_5fmap',['scan_map',['../sokoban__io_8c.html#a22e161d7a51e3e572048f289def03f5b',1,'scan_map(char *map_name):&#160;sokoban_io.c'],['../sokoban__io_8h.html#a22e161d7a51e3e572048f289def03f5b',1,'scan_map(char *map_name):&#160;sokoban_io.c']]],
  ['screen',['screen',['../main_8c.html#a78fa3957d73de49cb81d047857504218',1,'main.c']]],
  ['sokoban_5fio_2ec',['sokoban_io.c',['../sokoban__io_8c.html',1,'']]],
  ['sokoban_5fio_2eh',['sokoban_io.h',['../sokoban__io_8h.html',1,'']]],
  ['sokoban_5flogic_2ec',['sokoban_logic.c',['../sokoban__logic_8c.html',1,'']]],
  ['sokoban_5flogic_2eh',['sokoban_logic.h',['../sokoban__logic_8h.html',1,'']]],
  ['sokoban_5fmap_2eh',['sokoban_map.h',['../sokoban__map_8h.html',1,'']]],
  ['step',['step',['../sokoban__logic_8c.html#a3ad1e3a11f5fe5c7e0f82e580fe572d0',1,'step(map_struct *map, int step_dir):&#160;sokoban_logic.c'],['../sokoban__logic_8h.html#a3ad1e3a11f5fe5c7e0f82e580fe572d0',1,'step(map_struct *map, int step_dir):&#160;sokoban_logic.c']]],
  ['step_5fexecute',['step_execute',['../sokoban__logic_8c.html#abff18487b97ac422afa57da7b5b0200d',1,'sokoban_logic.c']]],
  ['step_5foffset',['step_offset',['../sokoban__logic_8c.html#afef9f859e64b233f38124009c8451c4e',1,'sokoban_logic.c']]],
  ['step_5ftile_5fswitch',['step_tile_switch',['../sokoban__logic_8c.html#af8cad0a679461f11ab0dc26117f225fa',1,'sokoban_logic.c']]],
  ['steps',['steps',['../structmap__struct.html#ab4ae7205573977222eadd0795db193e2',1,'map_struct']]],
  ['steps_5ftaken',['steps_taken',['../structrecord__struct.html#ac3cd35a2fb6053f3a8564c5f72912806',1,'record_struct']]],
  ['surfaces_5fstruct',['surfaces_struct',['../structsurfaces__struct.html',1,'surfaces_struct'],['../main_8c.html#adfab176c19d065e6874f194c7d8f8ef2',1,'surfaces_struct():&#160;main.c']]]
];
