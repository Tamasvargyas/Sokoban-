var searchData=
[
  ['destination',['destination',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557ae7549357dc400eeb39858632e04d66b6',1,'sokoban_map.h']]],
  ['destination_5fsurface',['destination_surface',['../structsurfaces__struct.html#a2db22e61ab34829bdb55687fffb7e4cb',1,'surfaces_struct']]],
  ['do_5fstep',['do_step',['../structoffset__stuct.html#aba3ede4b52d7063a4dbce0a3ec9c9e83',1,'offset_stuct']]],
  ['down',['down',['../sokoban__logic_8c.html#a06fc87d81c62e9abb8790b6e5713c55ba00156fc42b17a87d0746d97b42caf296',1,'sokoban_logic.c']]]
];
