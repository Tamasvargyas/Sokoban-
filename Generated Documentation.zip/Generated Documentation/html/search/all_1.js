var searchData=
[
  ['char_5fdes',['char_des',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557a02ec363ec85418a05cf43b715df0a040',1,'sokoban_map.h']]],
  ['char_5fon_5fdes',['char_on_des',['../structmap__struct.html#aefcf1dcb7f5806fa1c22f49b332dfe6c',1,'map_struct']]],
  ['char_5fx',['char_x',['../structmap__struct.html#afb9a2dca4d51d2defa5e5b1ee96fe7e5',1,'map_struct']]],
  ['char_5fy',['char_y',['../structmap__struct.html#a7df89d0a258ae9b4fe4668dad8c027ca',1,'map_struct']]],
  ['character',['character',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557afa40ef3af4fea0001b535318130960b2',1,'sokoban_map.h']]],
  ['character_5fsurface',['character_surface',['../structsurfaces__struct.html#a0e0858ad5fc334d19f2c248f46155854',1,'surfaces_struct']]],
  ['choose_5fmap',['choose_map',['../sokoban__io_8c.html#ad7788a2252c3bbc855d268f45bc7dfd5',1,'choose_map(int map_number):&#160;sokoban_io.c'],['../sokoban__io_8h.html#ad7788a2252c3bbc855d268f45bc7dfd5',1,'choose_map(int map_number):&#160;sokoban_io.c']]]
];
