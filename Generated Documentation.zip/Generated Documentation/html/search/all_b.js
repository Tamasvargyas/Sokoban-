var searchData=
[
  ['offset_5fstruct',['offset_struct',['../sokoban__logic_8c.html#afa60ae58827677bbe7375d89183a6239',1,'sokoban_logic.c']]],
  ['offset_5fstuct',['offset_stuct',['../structoffset__stuct.html',1,'']]],
  ['open_5fmap',['open_map',['../main_8c.html#ad05d60230343eba96e9a5e61226e7bd9',1,'main.c']]],
  ['outside',['outside',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557ac8da1cf898317d8ad0684c8e696e7e7f',1,'sokoban_map.h']]],
  ['outside_5fsurface',['outside_surface',['../structsurfaces__struct.html#a11c82db5c70c0355ed37536633c5ba36',1,'surfaces_struct']]]
];
