var searchData=
[
  ['main',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['map_5fnumber',['map_number',['../structrecord__struct.html#af7506a927da240fe7ad11a448c159beb',1,'record_struct']]],
  ['map_5fstruct',['map_struct',['../structmap__struct.html',1,'map_struct'],['../sokoban__map_8h.html#ab9b000e842f004732bd353ff450b3c05',1,'map_struct():&#160;sokoban_map.h']]],
  ['menu_5fsurface',['menu_surface',['../structsurfaces__struct.html#af7a64fde6b92b34b7809058b62554816',1,'surfaces_struct']]]
];
