var searchData=
[
  ['player_5fname',['player_name',['../structrecord__struct.html#a570743d8b8353759f4d18adadf9b65ad',1,'record_struct']]]
];
