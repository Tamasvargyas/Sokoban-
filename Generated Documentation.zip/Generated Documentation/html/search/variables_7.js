var searchData=
[
  ['map_5fnumber',['map_number',['../structrecord__struct.html#af7506a927da240fe7ad11a448c159beb',1,'record_struct']]],
  ['menu_5fsurface',['menu_surface',['../structsurfaces__struct.html#af7a64fde6b92b34b7809058b62554816',1,'surfaces_struct']]]
];
