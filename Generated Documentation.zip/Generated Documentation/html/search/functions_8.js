var searchData=
[
  ['scan_5fmap',['scan_map',['../sokoban__io_8c.html#a22e161d7a51e3e572048f289def03f5b',1,'scan_map(char *map_name):&#160;sokoban_io.c'],['../sokoban__io_8h.html#a22e161d7a51e3e572048f289def03f5b',1,'scan_map(char *map_name):&#160;sokoban_io.c']]],
  ['step',['step',['../sokoban__logic_8c.html#a3ad1e3a11f5fe5c7e0f82e580fe572d0',1,'step(map_struct *map, int step_dir):&#160;sokoban_logic.c'],['../sokoban__logic_8h.html#a3ad1e3a11f5fe5c7e0f82e580fe572d0',1,'step(map_struct *map, int step_dir):&#160;sokoban_logic.c']]],
  ['step_5fexecute',['step_execute',['../sokoban__logic_8c.html#abff18487b97ac422afa57da7b5b0200d',1,'sokoban_logic.c']]],
  ['step_5foffset',['step_offset',['../sokoban__logic_8c.html#afef9f859e64b233f38124009c8451c4e',1,'sokoban_logic.c']]],
  ['step_5ftile_5fswitch',['step_tile_switch',['../sokoban__logic_8c.html#af8cad0a679461f11ab0dc26117f225fa',1,'sokoban_logic.c']]]
];
