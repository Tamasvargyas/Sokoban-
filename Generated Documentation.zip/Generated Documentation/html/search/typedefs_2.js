var searchData=
[
  ['record_5fstruct',['record_struct',['../sokoban__io_8c.html#a344248fef48d77b9c16efe8a51184111',1,'sokoban_io.c']]]
];
