var searchData=
[
  ['record_5fstruct',['record_struct',['../structrecord__struct.html',1,'']]]
];
