var searchData=
[
  ['destination_5fsurface',['destination_surface',['../structsurfaces__struct.html#a2db22e61ab34829bdb55687fffb7e4cb',1,'surfaces_struct']]],
  ['do_5fstep',['do_step',['../structoffset__stuct.html#aba3ede4b52d7063a4dbce0a3ec9c9e83',1,'offset_stuct']]]
];
