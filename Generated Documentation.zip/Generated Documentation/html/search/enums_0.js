var searchData=
[
  ['tile_5ftype',['tile_type',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557',1,'sokoban_map.h']]]
];
