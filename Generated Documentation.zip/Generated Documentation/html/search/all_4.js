var searchData=
[
  ['floor',['floor',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557aa2cd0f2689920d3196cebb39ef6f9afb',1,'sokoban_map.h']]],
  ['floor_5fsurface',['floor_surface',['../structsurfaces__struct.html#ade4d5eb22f28c081e622396378a9c00c',1,'surfaces_struct']]],
  ['free_5fmap',['free_map',['../sokoban__io_8c.html#afdfc830905135788f014a9dd2e068283',1,'free_map(map_struct *map):&#160;sokoban_io.c'],['../sokoban__io_8h.html#afdfc830905135788f014a9dd2e068283',1,'free_map(map_struct *map):&#160;sokoban_io.c']]],
  ['free_5fsurfaces',['free_surfaces',['../main_8c.html#a3bf575588a75b4679c49c7be38ca6fdc',1,'main.c']]]
];
