var searchData=
[
  ['up',['up',['../sokoban__logic_8c.html#a06fc87d81c62e9abb8790b6e5713c55baebc281bf093563220c2270ba57dedfce',1,'sokoban_logic.c']]]
];
