var searchData=
[
  ['tile_5ftype',['tile_type',['../sokoban__map_8h.html#ad39b233e9cefabbb072e1cad31e0aaa1',1,'sokoban_map.h']]]
];
