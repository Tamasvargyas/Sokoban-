var searchData=
[
  ['height',['height',['../structmap__struct.html#ad12fc34ce789bce6c8a05d8a17138534',1,'map_struct']]],
  ['hor',['hor',['../structoffset__stuct.html#a9b174252bf74fcf61c66527b24e23d3e',1,'offset_stuct']]]
];
