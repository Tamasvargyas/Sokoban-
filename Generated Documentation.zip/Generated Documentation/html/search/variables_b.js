var searchData=
[
  ['screen',['screen',['../main_8c.html#a78fa3957d73de49cb81d047857504218',1,'main.c']]],
  ['steps',['steps',['../structmap__struct.html#ab4ae7205573977222eadd0795db193e2',1,'map_struct']]],
  ['steps_5ftaken',['steps_taken',['../structrecord__struct.html#ac3cd35a2fb6053f3a8564c5f72912806',1,'record_struct']]]
];
