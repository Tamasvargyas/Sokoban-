var searchData=
[
  ['outside_5fsurface',['outside_surface',['../structsurfaces__struct.html#a11c82db5c70c0355ed37536633c5ba36',1,'surfaces_struct']]]
];
