var searchData=
[
  ['record',['record',['../sokoban__io_8c.html#ad4bff0a4e6278130f71b62593659fdeb',1,'record(int map_number, char *player_name, int steps_taken):&#160;sokoban_io.c'],['../sokoban__io_8h.html#ad4bff0a4e6278130f71b62593659fdeb',1,'record(int map_number, char *player_name, int steps_taken):&#160;sokoban_io.c']]]
];
