var searchData=
[
  ['box_5fdes',['box_des',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557a1e6ad9cdb2f2b096699ed804a75cfba2',1,'sokoban_map.h']]],
  ['box_5ffloor',['box_floor',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557a2d6b324d6e8eed66de1ec12ce954c10e',1,'sokoban_map.h']]]
];
