var searchData=
[
  ['tile',['tile',['../structmap__struct.html#a382bd3e640d3f496ba021ba2df917431',1,'map_struct']]],
  ['tile_5ftype',['tile_type',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557',1,'tile_type():&#160;sokoban_map.h'],['../sokoban__map_8h.html#ad39b233e9cefabbb072e1cad31e0aaa1',1,'tile_type():&#160;sokoban_map.h']]]
];
