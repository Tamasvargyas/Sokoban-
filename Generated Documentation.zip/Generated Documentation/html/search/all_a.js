var searchData=
[
  ['new_5frecord_5fsurface',['new_record_surface',['../structsurfaces__struct.html#aaf434028a3aa45cd0d0fb47b3566c326',1,'surfaces_struct']]]
];
