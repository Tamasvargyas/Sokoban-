var searchData=
[
  ['box_5fcount',['box_count',['../structmap__struct.html#ab0ceb59cf1023256275abc572df0bf34',1,'map_struct']]],
  ['box_5fdes_5fsurface',['box_des_surface',['../structsurfaces__struct.html#a2c64a3541af0d7e1757fe5d6cb3e5bb8',1,'surfaces_struct']]],
  ['box_5ffloor_5fsurface',['box_floor_surface',['../structsurfaces__struct.html#a8c1a2b4692ee0e888efdcb54aa2199e6',1,'surfaces_struct']]]
];
