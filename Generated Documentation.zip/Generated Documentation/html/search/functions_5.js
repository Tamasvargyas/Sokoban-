var searchData=
[
  ['open_5fmap',['open_map',['../main_8c.html#ad05d60230343eba96e9a5e61226e7bd9',1,'main.c']]]
];
