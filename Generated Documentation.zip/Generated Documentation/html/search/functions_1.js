var searchData=
[
  ['choose_5fmap',['choose_map',['../sokoban__io_8c.html#ad7788a2252c3bbc855d268f45bc7dfd5',1,'choose_map(int map_number):&#160;sokoban_io.c'],['../sokoban__io_8h.html#ad7788a2252c3bbc855d268f45bc7dfd5',1,'choose_map(int map_number):&#160;sokoban_io.c']]]
];
