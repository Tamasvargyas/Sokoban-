var searchData=
[
  ['char_5fon_5fdes',['char_on_des',['../structmap__struct.html#aefcf1dcb7f5806fa1c22f49b332dfe6c',1,'map_struct']]],
  ['char_5fx',['char_x',['../structmap__struct.html#afb9a2dca4d51d2defa5e5b1ee96fe7e5',1,'map_struct']]],
  ['char_5fy',['char_y',['../structmap__struct.html#a7df89d0a258ae9b4fe4668dad8c027ca',1,'map_struct']]],
  ['character_5fsurface',['character_surface',['../structsurfaces__struct.html#a0e0858ad5fc334d19f2c248f46155854',1,'surfaces_struct']]]
];
