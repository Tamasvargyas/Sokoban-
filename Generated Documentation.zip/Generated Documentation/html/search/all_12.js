var searchData=
[
  ['wall',['wall',['../sokoban__map_8h.html#aead19eca2c94521d792999604f330557a266a0f2740c53325df0b7424a6c171bf',1,'sokoban_map.h']]],
  ['wall_5fsurface',['wall_surface',['../structsurfaces__struct.html#a359a079547b02a165999810f6b9bf0d1',1,'surfaces_struct']]]
];
